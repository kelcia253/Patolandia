package com.tds.ifsc;

public interface Quack {
	public void quack();
}
