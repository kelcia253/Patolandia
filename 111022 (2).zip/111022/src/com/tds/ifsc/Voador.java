package com.tds.ifsc;

public interface Voador {
	public void voar();
}
