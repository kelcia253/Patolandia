package com.tds.ifsc;

public class Pato {
	
	public Pato() {
		
	}
	
	public void nadar() {
		System.out.println("Estou nadando!");
	}
	
	public void display() {
		System.out.println("Oi, eu sou um pato!");
	}
}
