package com.tds.ifsc;

public class PatoMadeira extends Pato{
	
	public void display() {
		System.out.println("Oi, eu sou um Pato de Madeira!");
	}
	
	public void enfeite() {
		System.out.println("Eu enfeito c�modos!");
	}
}
