package com.tds.ifsc;

public class PatoBorracha extends Pato{
	
	public void display() {
		System.out.println("Oi, eu sou um pato de borracha!");
	}
	
	public void boiar() {
		System.out.println("Estou boiando!");
	}
	
	public void squeck() {
		System.out.println("Squeck! Squeck! Squeck!");
	}
}
